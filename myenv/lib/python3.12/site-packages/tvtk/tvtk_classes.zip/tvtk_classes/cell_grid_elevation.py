# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.cell_grid_algorithm import CellGridAlgorithm


class CellGridElevation(CellGridAlgorithm):
    r"""
    CellGridElevation - Adds a cell attribute representing elevation.
    
    Superclass: CellGridAlgorithm
    
    This filter adds a new cell attribute – named "Elevation" by
    default – to an input CellGrid. The cell attribute is
    scalar-valued and generally represents distance from some point along
    one or more axes.
    
    In order to make the attribute more interesting for demonstration
    purposes, an additional "shock" parameter can be used by responders
    to introduce discontinuities in the attribute at cell boundaries (for
    cells which allow discontinuities such as DGCell).
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCellGridElevation, obj, update, **traits)
    
    attribute_name = traits.Trait(None, None, traits.String(enter_set=True, auto_set=False), desc=\
        r"""
        Set/get the name of the generated CellAttribute.
        
        The default is `elevation` if no value is provided.
        """
    )

    def _attribute_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAttributeName,
                        self.attribute_name)

    axis = traits.Array(enter_set=True, auto_set=False, shape=(None,), dtype="float", value=(0.0, 0.0, 1.0), cols=3, desc=\
        r"""
        Set/get the principal direction along which elevation is
        measured. The exact way the axis is used varies with the
        number_of_axes setting.
        """
    )

    def _axis_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAxis,
                        self.axis)

    number_of_axes = traits.Trait(1, traits.Range(1, 3, enter_set=True, auto_set=False), desc=\
        r"""
        Set/get the number of axes along which elevation is measured.
        This is a number between 1 and 3, inclusive. These correspond to:
        + 1 – **linear**: elevation is measured by projecting any test
        point
              to Axis, then computing the distance to the Origin. + 2 –
        **cylindrical**: elevation is measured from the nearest point
              along the line passing through the Origin along the Axis.
              All points along line have an elevation of 0. + 3 –
        **spherical**: elevation is measured using the L² norm of the
              vector from the Origin to each test point. The Axis is
              ignored.
        
        The default is 1 (linear).
        """
    )

    def _number_of_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfAxes,
                        self.number_of_axes)

    origin = traits.Array(enter_set=True, auto_set=False, shape=(None,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        Set/get the location where the output scalar is zero.
        """
    )

    def _origin_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOrigin,
                        self.origin)

    shock = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/get the "shock" value, which is a distance added to each
        elevation value proportional to the distance from the cell center
        to the test point within that cell. The intent is to provide a
        way to introduce discontinuities into the field to demonstrate
        the capabilities of DG cells.
        """
    )

    def _shock_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetShock,
                        self.shock)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('attribute_name', 'GetAttributeName'), ('axis', 'GetAxis'),
    ('number_of_axes', 'GetNumberOfAxes'), ('origin', 'GetOrigin'),
    ('shock', 'GetShock'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'attribute_name', 'axis',
    'number_of_axes', 'object_name', 'origin', 'progress_text', 'shock'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CellGridElevation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CellGridElevation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'attribute_name', 'axis',
            'number_of_axes', 'object_name', 'origin', 'shock']),
            title='Edit CellGridElevation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CellGridElevation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

