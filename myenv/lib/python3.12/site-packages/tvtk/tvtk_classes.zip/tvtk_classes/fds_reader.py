# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.partitioned_data_set_collection_algorithm import PartitionedDataSetCollectionAlgorithm


class FDSReader(PartitionedDataSetCollectionAlgorithm):
    r"""
    FDSReader - A reader for the Fire Dynamics Simulator (FDS) output
    data.
    
    Superclass: PartitionedDataSetCollectionAlgorithm
    
    This class reads in the `.smv` file and uses the meta-data to
    identify the other files to read automatically. It outputs a
    `vtkpartitioned_data_set_collection` containing 5 groups: Grids,
    Devices, HRR, Slices and Boundaries. Each group contains data sets
    with the expected values for users of the FDS code.
    
    FDS & SMV specifications :
    https://pages.nist.gov/fds-smv/manuals.html
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkFDSReader, obj, update, **traits)
    
    file_name = tvtk_base.vtk_file_name("", desc=\
        r"""
        Specifies the name of the .smv file to be loaded.
        """
    )

    def _file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFileName,
                        self.file_name)

    def _get_stream(self):
        return wrap_vtk(self._vtk_obj.GetStream())
    def _set_stream(self, arg):
        old_val = self._get_stream()
        self._wrap_call(self._vtk_obj.SetStream,
                        deref_vtk(arg))
        self.trait_property_changed('stream', old_val, arg)
    stream = traits.Property(_get_stream, _set_stream, desc=\
        r"""
        
        """
    )

    time_tolerance = traits.Float(1e-05, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _time_tolerance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTimeTolerance,
                        self.time_tolerance)

    def _get_assembly(self):
        return wrap_vtk(self._vtk_obj.GetAssembly())
    assembly = traits.Property(_get_assembly, desc=\
        r"""
        Get the data full data assembly associated with the input
        """
    )

    def _get_assembly_tag(self):
        return self._vtk_obj.GetAssemblyTag()
    assembly_tag = traits.Property(_get_assembly_tag, desc=\
        r"""
        Whenever the assembly is changed, this tag gets changed. Note,
        users should not assume that this is monotonically increasing but
        instead simply rely on its value to determine if the assembly may
        have changed since last time.
        
        It is set to 0 whenever there's no valid assembly available.
        """
    )

    def add_selector(self, *args):
        """
        add_selector(self, selector:str) -> bool
        C++: bool add_selector(const char *selector)
        API to set selectors. Multiple selectors can be added using
        `add_selector`. The order in which selectors are specified is not
        preserved and has no impact on the result.
        
        `add_selector` returns true if the selector was added, false if
        the selector was already specified and hence not added.
        
        @sa DataAssembly::SelectNodes
        """
        ret = self._wrap_call(self._vtk_obj.AddSelector, *args)
        return ret

    def clear_selectors(self):
        """
        clear_selectors(self) -> None
        C++: void clear_selectors()"""
        ret = self._vtk_obj.ClearSelectors()
        return ret
        

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('file_name',
    'GetFileName'), ('time_tolerance', 'GetTimeTolerance'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'file_name', 'object_name',
    'progress_text', 'time_tolerance'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(FDSReader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit FDSReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'file_name', 'object_name',
            'time_tolerance']),
            title='Edit FDSReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit FDSReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

