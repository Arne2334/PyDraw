# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.partitioned_data_set_collection_algorithm import PartitionedDataSetCollectionAlgorithm


class AppendPartitionedDataSetCollection(PartitionedDataSetCollectionAlgorithm):
    r"""
    AppendPartitionedDataSetCollection - Append partitioned dataset
    collections.
    
    Superclass: PartitionedDataSetCollectionAlgorithm
    
    AppendPartitionedDataSetCollection is a filter that appends input
    partitioned dataset collections with the same number of partitions
    and assembly (if present) into a single output partitioned dataset
    collection. Each partitioned dataset of the output partitioned
    dataset collection will either have 1 partition (merging occurs) or
    the N partitions, where N is the summation of the number of
    partitions of the corresponding partitioned datasets of the input
    partitioned dataset collections. To select the mode of the append
    filter, use the set_append_mode method.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkAppendPartitionedDataSetCollection, obj, update, **traits)
    
    append_field_data = tvtk_base.true_bool_trait(desc=\
        r"""
        Set/Get whether to append the field data of the input partitioned
        dataset collections.
        
        The default is true.
        """
    )

    def _append_field_data_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAppendFieldData,
                        self.append_field_data_)

    append_mode = tvtk_base.RevPrefixMap({'append_partitions': 0, 'merge_partitions': 1}, default_value='append_partitions', desc=\
        r"""
        Set/Get the mode of the append filter.
        
        The default mode is APPEND_PARTITIONED_DATASETS.
        """
    )

    def _append_mode_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAppendMode,
                        self.append_mode_)

    _updateable_traits_ = \
    (('append_field_data', 'GetAppendFieldData'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('append_mode', 'GetAppendMode'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'append_field_data', 'debug',
    'global_warning_display', 'release_data_flag', 'append_mode',
    'abort_output', 'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(AppendPartitionedDataSetCollection, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit AppendPartitionedDataSetCollection properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['append_field_data'], ['append_mode'], ['abort_output',
            'object_name']),
            title='Edit AppendPartitionedDataSetCollection properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit AppendPartitionedDataSetCollection properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

