# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.mapper import Mapper


class ArrayRenderer(Mapper):
    r"""
    ArrayRenderer - Render instanced elements textured with arrays
    from input data.
    
    Superclass: Mapper
    
    This currently handles hexahedra and tetrahedra.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkArrayRenderer, obj, update, **traits)
    
    fragment_shader_source = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        Set/get the source for the fragment shader.
        
        This is not identical to the source sent to open_gl; there may be
        replacements made by any attached GLSL modifier objects.
        """
    )

    def _fragment_shader_source_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFragmentShaderSource,
                        self.fragment_shader_source)

    has_opaque = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _has_opaque_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetHasOpaque,
                        self.has_opaque)

    has_translucent = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _has_translucent_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetHasTranslucent,
                        self.has_translucent)

    vertex_shader_source = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        Set/get the source for the vertex shader.
        
        This is not identical to the source sent to open_gl; there may be
        replacements made by any attached GLSL modifier objects.
        """
    )

    def _vertex_shader_source_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetVertexShaderSource,
                        self.vertex_shader_source)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input as a DataSet.  This method is overridden in the
        specialized mapper classes to return more specific data types.
        """
    )

    def get_shader(self, *args):
        """
        get_shader(self, shaderType:Shader.Type) -> Shader
        C++: Shader *get_shader(Shader::Type shaderType)
        Return a shader of the given type (creating as needed).
        """
        ret = self._wrap_call(self._vtk_obj.GetShader, *args)
        return ret

    def add_mod(self, *args):
        """
        add_mod(self, className:str) -> None
        C++: void add_mod(const std::string &className)"""
        ret = self._wrap_call(self._vtk_obj.AddMod, *args)
        return ret

    def add_mods(self, *args):
        """
        add_mods(self, classNames:(str, ...)) -> None
        C++: void add_mods(const std::vector<std::string> &classNames)"""
        ret = self._wrap_call(self._vtk_obj.AddMods, *args)
        return ret

    def bind_array_to_texture(self, *args):
        """
        bind_array_to_texture(self, textureName:StringToken,
            array:DataArray, asScalars:bool=False) -> None
        C++: void bind_array_to_texture(StringToken textureName,
            DataArray *array, bool asScalars=false)
        Bind a data array to the given textureName (used in shader
        program texelFetch calls).
        
        If asScalars is false (the default), then the array's components
        are treated as components of single texture values. If asScalars
        is true, then a 2-d texture image is uploaded where each value is
        a scalar (row indices are tuple IDs, column indices are component
        IDs).
        """
        ret = self._wrap_call(self._vtk_obj.BindArrayToTexture, *args)
        return ret

    def prepare_colormap(self, *args):
        """
        prepare_colormap(self, cmap:ScalarsToColors=...) -> None
        C++: void prepare_colormap(ScalarsToColors *cmap=nullptr)
        Prepare a colormap for use in a shader.
        
        If you provide a lookup table, it will be uploaded as a 2-D
        texture named "color_map" for you to use in your shaders. If not,
        a default cool-to-warm colormap will be created.
        
        This function may call create_colormap_texture().
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.PrepareColormap, *my_args)
        return ret

    def remove_all_mods(self):
        """
        remove_all_mods(self) -> None
        C++: void remove_all_mods()"""
        ret = self._vtk_obj.RemoveAllMods()
        return ret
        

    def remove_mod(self, *args):
        """
        remove_mod(self, className:str) -> None
        C++: void remove_mod(const std::string &className)"""
        ret = self._wrap_call(self._vtk_obj.RemoveMod, *args)
        return ret

    def reset_mods_to_default(self):
        """
        reset_mods_to_default(self) -> None
        C++: void reset_mods_to_default()"""
        ret = self._vtk_obj.ResetModsToDefault()
        return ret
        

    def set_element_type(self, *args):
        """
        set_element_type(self, elementType:int) -> bool
        C++: virtual bool set_element_type(int elementType)"""
        ret = self._wrap_call(self._vtk_obj.SetElementType, *args)
        return ret

    def set_number_of_elements(self, *args):
        """
        set_number_of_elements(self, numberOfElements:int) -> bool
        C++: virtual bool set_number_of_elements(IdType numberOfElements)"""
        ret = self._wrap_call(self._vtk_obj.SetNumberOfElements, *args)
        return ret

    def set_number_of_instances(self, *args):
        """
        set_number_of_instances(self, numberOfInstances:int) -> bool
        C++: virtual bool set_number_of_instances(
            IdType numberOfInstances)"""
        ret = self._wrap_call(self._vtk_obj.SetNumberOfInstances, *args)
        return ret

    _updateable_traits_ = \
    (('interpolate_scalars_before_mapping',
    'GetInterpolateScalarsBeforeMapping'), ('scalar_visibility',
    'GetScalarVisibility'), ('static', 'GetStatic'),
    ('use_lookup_table_scalar_range', 'GetUseLookupTableScalarRange'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('color_mode',
    'GetColorMode'), ('resolve_coincident_topology',
    'GetResolveCoincidentTopology'), ('scalar_mode', 'GetScalarMode'),
    ('fragment_shader_source', 'GetFragmentShaderSource'), ('has_opaque',
    'GetHasOpaque'), ('has_translucent', 'GetHasTranslucent'),
    ('vertex_shader_source', 'GetVertexShaderSource'),
    ('array_access_mode', 'GetArrayAccessMode'), ('array_component',
    'GetArrayComponent'), ('array_id', 'GetArrayId'), ('array_name',
    'GetArrayName'), ('field_data_tuple_id', 'GetFieldDataTupleId'),
    ('render_time', 'GetRenderTime'),
    ('resolve_coincident_topology_polygon_offset_faces',
    'GetResolveCoincidentTopologyPolygonOffsetFaces'),
    ('resolve_coincident_topology_z_shift',
    'GetResolveCoincidentTopologyZShift'), ('scalar_range',
    'GetScalarRange'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'interpolate_scalars_before_mapping', 'release_data_flag',
    'scalar_visibility', 'static', 'use_lookup_table_scalar_range',
    'color_mode', 'resolve_coincident_topology', 'scalar_mode',
    'abort_output', 'array_access_mode', 'array_component', 'array_id',
    'array_name', 'field_data_tuple_id', 'fragment_shader_source',
    'has_opaque', 'has_translucent', 'object_name', 'progress_text',
    'render_time', 'resolve_coincident_topology_polygon_offset_faces',
    'resolve_coincident_topology_z_shift', 'scalar_range',
    'vertex_shader_source'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ArrayRenderer, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ArrayRenderer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['interpolate_scalars_before_mapping', 'scalar_visibility',
            'static', 'use_lookup_table_scalar_range'], ['color_mode',
            'resolve_coincident_topology', 'scalar_mode'], ['abort_output',
            'array_access_mode', 'array_component', 'array_id', 'array_name',
            'field_data_tuple_id', 'fragment_shader_source', 'has_opaque',
            'has_translucent', 'object_name', 'render_time',
            'resolve_coincident_topology_polygon_offset_faces',
            'resolve_coincident_topology_z_shift', 'scalar_range',
            'vertex_shader_source']),
            title='Edit ArrayRenderer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ArrayRenderer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

