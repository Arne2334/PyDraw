# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class Deserializer(Object):
    r"""
    Deserializer - Deserialize VTK objects from JSON.
    
    Superclass: Object
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkDeserializer, obj, update, **traits)
    
    def _get_context(self):
        return wrap_vtk(self._vtk_obj.GetContext())
    def _set_context(self, arg):
        old_val = self._get_context()
        self._wrap_call(self._vtk_obj.SetContext,
                        deref_vtk(arg))
        self.trait_property_changed('context', old_val, arg)
    context = traits.Property(_get_context, _set_context, desc=\
        r"""
        
        """
    )

    def construct_object(self, *args):
        """
        construct_object(self, className:str, superClassNames:(str, ...))
            -> ObjectBase
        C++: ObjectBase *construct_object(const std::string &className,
            const std::vector<std::string> &superClassNames)
        Constructs an object of type `className`.
        
        If a constructor is not found for `className`, the
        `get_constructor` walks through each item in `superclass_names` and
        attempts to construct an instance of that type. This is useful
        when the VTK build of the serializer side and the deserializer
        side are on entirely different platforms by taking advantage of
        the object factory mechanism.
        
        Example of usefulness of `superclass_names`:
        
        Let's suppose in a Windows VTK application, the `Serializer`
        serialized an instance of `vtkwin32_render_window_interactor` into
        json which was then transferred over the network to a macOS
        machine. Over there, seeing that the state refers to the
        `vtkwin32_render_window_interactor` class the `Deserializer` will
        attempt to find a constructor for win32 class and fail. It then
        checks if the super class (here `vtkrender_window_interactor`) has
        a constructor and constructs a new instance of that type. Due to
        the object factory mechanism, the macOS build of VTK constructs a
        `vtkcocoa_render_window_interactor` and it all works as expected!
        """
        ret = self._wrap_call(self._vtk_obj.ConstructObject, *args)
        return wrap_vtk(ret)

    def deserialize_json(self, *args):
        """
        deserialize_json(self, identifier:int, objectBase:ObjectBase)
            -> bool
        C++: bool deserialize_json(const TypeUInt32 &identifier,
            SmartPointer<vtkObjectBase> &objectBase)
        Deserialize a state registered with the context at `identifier`
        into `objectBase`. This function lets you pass a non-null object
        into `objectBase` typically obtained from
        MarshalContext::GetObjectAtId. In that case, the constructor
        is not invoked. Otherwise, a new object will be constructed and
        available in `objectBase`.
        
        This method returns `true` if the state was successfully
        deserialized and `false` when an error occurs. This method
        returns `true` if the state was already deserialized into an
        object.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.DeserializeJSON, *my_args)
        return ret

    def un_register_constructor(self, *args):
        """
        un_register_constructor(self, className:str) -> None
        C++: void un_register_constructor(const std::string &className)"""
        ret = self._wrap_call(self._vtk_obj.UnRegisterConstructor, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Deserializer, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Deserializer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit Deserializer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Deserializer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

