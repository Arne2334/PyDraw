# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.resource_stream import ResourceStream


class MemoryResourceStream(ResourceStream):
    r"""
    MemoryResourceStream - `vtkresource_stream` implementation for
    memory input.
    
    Superclass: ResourceStream
    
    `vtkmemory_resource_stream` can be a view on existing data. Or it can
    copy specified data into an internal buffer. Or it can take ownership
    of a `Buffer`, a `std::vector` or a `std::string`.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkMemoryResourceStream, obj, update, **traits)
    
    def owns_buffer(self):
        """
        owns_buffer(self) -> bool
        C++: bool owns_buffer()
        Check if `this` has a internally managed buffer
        
        This is `true` after a call to
        `set_buffer(vtksmart_pointer<Buffer>)` even if only the
        reference count is managed by the stream.
        
        @return `true` if `this` manage streamed buffer, `false`
            otherwise.
        """
        ret = self._vtk_obj.OwnsBuffer()
        return ret
        

    def set_buffer(self, *args):
        """
        set_buffer(self, buffer:Pointer, size:int, copy:bool=False) -> None
        C++: void set_buffer(const void *buffer, std::size_t size,
            bool copy=false)
        Set buffer to stream
        
        If `copy` is `false`, the source buffer must stay valid as it may
        be used.
        
        Otherwise, if `copy` is `true`, given buffer will be copied into
        an internally managed buffer. If `size` is 0, this call won't
        allocate anything. If `size > 0`, `buffer` must not be `nullptr`
        and must point to a contiguous buffer of at least `size` bytes.
        
        Regardless of `copy` value, this function also has the following
        effects:
        - Reset stream position to `0`.
        - end_of_stream will return `true` if `size` is `0`, `false`
          otherwise.
        - Release currently owned buffer, if any.
        - Increase modified time.
        
        @param buffer the buffer address, may be nullptr if `size` is 0.
        @param size the buffer size in bytes, may be 0.
        @param copy if `true` this function copies given buffer to an
            internally managed buffer.
        """
        ret = self._wrap_call(self._vtk_obj.SetBuffer, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(MemoryResourceStream, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit MemoryResourceStream properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit MemoryResourceStream properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit MemoryResourceStream properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

