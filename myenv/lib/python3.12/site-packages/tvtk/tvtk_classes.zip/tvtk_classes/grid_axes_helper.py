# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class GridAxesHelper(Object):
    r"""
    GridAxesHelper - is a helper object used by GridAxesActor2D,
    GridAxesActor3D, and GridAxesPlane2DActor.
    
    Superclass: Object
    
    GridAxesActor2D, GridAxesActor3D, and GridAxesPlane2DActor
    shares a lot of the computations and logic. This class makes it
    possible to share all such information between these classes. This
    class works with a single face of the bounding box specified using
    the grid_bounds.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkGridAxesHelper, obj, update, **traits)
    
    face = traits.Trait(1, traits.Range(1, 32, enter_set=True, auto_set=False), desc=\
        r"""
        Indicate which face of the specified bounds is this class
        operating with.
        
        By default, Face is GridAxesHelper::MIN_YZ.
        """
    )

    def _face_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFace,
                        self.face)

    grid_bounds = traits.Array(enter_set=True, auto_set=False, shape=(None,), dtype="float", value=(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0), cols=3, desc=\
        r"""
        Set the bounding box defining the grid space. This, together with
        theFace identify which planar surface this class is interested
        in. This class is designed to work with a single planar surface.
        
        Defaults to [-1.0, 1.0, -1.0, 1.0, -1.0, 1.0]
        """
    )

    def _grid_bounds_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGridBounds,
                        self.grid_bounds)

    label_mask = traits.Int(255, enter_set=True, auto_set=False, desc=\
        r"""
        Set the axes to label.
        
        By default, all axes are labeled i.e. label_mask = 0xff.
        """
    )

    def _label_mask_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLabelMask,
                        self.label_mask)

    def _get_matrix(self):
        return wrap_vtk(self._vtk_obj.GetMatrix())
    def _set_matrix(self, arg):
        old_val = self._get_matrix()
        self._wrap_call(self._vtk_obj.SetMatrix,
                        deref_vtk(arg))
        self.trait_property_changed('matrix', old_val, arg)
    matrix = traits.Property(_get_matrix, _set_matrix, desc=\
        r"""
        
        """
    )

    def _get_active_axes(self):
        return wrap_vtk(self._vtk_obj.GetActiveAxes())
    active_axes = traits.Property(_get_active_axes, desc=\
        r"""
        Returns which of the 3 coordinate axes for the 2 axes for this
        plane: 0 for X axis, 1, for Y axis, and 3 for Z axis. The two
        axes are specified in order so that together with the face normal
        (which is point outwards from the box defined by grid_bounds),
        they form a right-handed coordinate system.
        """
    )

    def _get_backface(self):
        return self._vtk_obj.GetBackface()
    backface = traits.Property(_get_backface, desc=\
        r"""
        Get if the face is facing backwards in the current viewport.
        """
    )

    def _get_label_visibilities(self):
        return wrap_vtk(self._vtk_obj.GetLabelVisibilities())
    label_visibilities = traits.Property(_get_label_visibilities, desc=\
        r"""
        Returns the visibility for labels for each of the 4 axis defined
        by the face points based on the label_mask.
        """
    )

    def _get_points(self):
        return wrap_vtk(self._vtk_obj.GetPoints())
    points = traits.Property(_get_points, desc=\
        r"""
        Get the 4 points in world coordinates that define the grid plane.
        The points are in anticlockwise anticlockwise order with the face
        normal pointing outward from the box defined by the grid_bounds.
        """
    )

    def _get_transformed_face_normal(self):
        return wrap_vtk(self._vtk_obj.GetTransformedFaceNormal())
    transformed_face_normal = traits.Property(_get_transformed_face_normal, desc=\
        r"""
        Get the normal to the grid plane face **after** applying the
        transform specified using transformation matrix. Similar to
        get_transformed_points(), this method will only compute when input
        parameters have changed since the last time this method was
        called.
        """
    )

    def _get_transformed_points(self):
        return wrap_vtk(self._vtk_obj.GetTransformedPoints())
    transformed_points = traits.Property(_get_transformed_points, desc=\
        r"""
        Get the 4 points of the plane transformed using the
        transformation matrix set using set_matrix(), if any. This method
        to compute the transformed points the first time its called since
        the plane points or the transformation matrix was set.
        """
    )

    def _get_viewport_normals(self):
        return wrap_vtk(self._vtk_obj.GetViewportNormals())
    viewport_normals = traits.Property(_get_viewport_normals, desc=\
        r"""
        Get the normals to the axis vectors in viewport space. There are
        not true normals to the axis vector. These are normalized.
        """
    )

    def _get_viewport_points(self):
        return wrap_vtk(self._vtk_obj.GetViewportPoints())
    viewport_points = traits.Property(_get_viewport_points, desc=\
        r"""
        Get the positions for the plane points in viewport coordinates.
        """
    )

    def _get_viewport_points_as_double(self):
        return wrap_vtk(self._vtk_obj.GetViewportPointsAsDouble())
    viewport_points_as_double = traits.Property(_get_viewport_points_as_double, desc=\
        r"""
        
        """
    )

    def _get_viewport_vectors(self):
        return wrap_vtk(self._vtk_obj.GetViewportVectors())
    viewport_vectors = traits.Property(_get_viewport_vectors, desc=\
        r"""
        Get the axis vectors formed using the points returned by
        get_viewport_points(). These are in non-normalized form.
        """
    )

    def transform_point(self, *args):
        """
        transform_point(self, point:Vector3d) -> Vector3d
        C++: Vector3d transform_point(const Vector3d &point)
        Transforms the give point using the Matrix.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.TransformPoint, *my_args)
        return wrap_vtk(ret)

    def update_for_viewport(self, *args):
        """
        update_for_viewport(self, viewport:Viewport) -> bool
        C++: bool update_for_viewport(Viewport *viewport)
        Call this method before accessing any of the attributes in
        viewport space. This computes the location of the plane in the
        viewport space using the specified viewport. This method should
        typically be called once per render.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.UpdateForViewport, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('face', 'GetFace'), ('grid_bounds',
    'GetGridBounds'), ('label_mask', 'GetLabelMask'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'face', 'grid_bounds',
    'label_mask', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(GridAxesHelper, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit GridAxesHelper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['face', 'grid_bounds', 'label_mask', 'object_name']),
            title='Edit GridAxesHelper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit GridAxesHelper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

