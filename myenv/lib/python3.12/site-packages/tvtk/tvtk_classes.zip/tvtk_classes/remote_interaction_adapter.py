# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class RemoteInteractionAdapter(Object):
    r"""
    RemoteInteractionAdapter - Map vtk-js interaction events to native
    VTK events
    
    Superclass: Object
    
    Apply an vtk-js events to a RenderWindowInteractor. For the
    expected format see
    https://github.com/Kitware/vtk-js/blob/master/Sources/Interaction/Styl
    e/interactor_style_remote_mouse/index.js
    
    Events are processed in the `process_event` method which can be called
    either as a static method providing all the relevant parameters as
    arguments or  a class method with the parameters provided via member
    variables.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkRemoteInteractionAdapter, obj, update, **traits)
    
    device_pixel_ratio = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _device_pixel_ratio_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDevicePixelRatio,
                        self.device_pixel_ratio)

    device_pixel_ratio_tolerance = traits.Float(1e-05, enter_set=True, auto_set=False, desc=\
        r"""
        Tolerance used when truncating the event position from physical
        to logical. i.e.  int event_position_x = int(event.at("x") *
        devicepixel_ratio + devicepixel_ratio_tolerance)
        """
    )

    def _device_pixel_ratio_tolerance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDevicePixelRatioTolerance,
                        self.device_pixel_ratio_tolerance)

    def _get_interactor(self):
        return wrap_vtk(self._vtk_obj.GetInteractor())
    def _set_interactor(self, arg):
        old_val = self._get_interactor()
        self._wrap_call(self._vtk_obj.SetInteractor,
                        deref_vtk(arg))
        self.trait_property_changed('interactor', old_val, arg)
    interactor = traits.Property(_get_interactor, _set_interactor, desc=\
        r"""
        
        """
    )

    def process_event(self, *args):
        """
        process_event(self, event:str) -> bool
        C++: bool process_event(const std::string &event)
        process_event(iren:RenderWindowInteractor, event:str,
            devicePixelRatio:float=1.0,
            devicePixelRatioTolerance:float=1e-5) -> bool
        C++: static bool process_event(RenderWindowInteractor *iren,
            const std::string &event, double devicePixelRatio=1.0,
            double devicePixelRatioTolerance=1e-5)
        Apply the vtk-js event to the internal render_window_interactor
        @param event stringified json representation of a vtk-js
            interaction event.
        @return true if the event is processed , false otherwise
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.ProcessEvent, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('device_pixel_ratio',
    'GetDevicePixelRatio'), ('device_pixel_ratio_tolerance',
    'GetDevicePixelRatioTolerance'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'device_pixel_ratio',
    'device_pixel_ratio_tolerance', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(RemoteInteractionAdapter, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit RemoteInteractionAdapter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['device_pixel_ratio', 'device_pixel_ratio_tolerance',
            'object_name']),
            title='Edit RemoteInteractionAdapter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit RemoteInteractionAdapter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

