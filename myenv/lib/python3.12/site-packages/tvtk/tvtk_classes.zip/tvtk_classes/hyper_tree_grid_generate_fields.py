# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.hyper_tree_grid_algorithm import HyperTreeGridAlgorithm


class HyperTreeGridGenerateFields(HyperTreeGridAlgorithm):
    r"""
    HyperTreeGridGenerateFields - Generate cell fields for a HTG
    
    Superclass: HyperTreeGridAlgorithm
    
    HyperTreeGridGenerateFields creates 2 distinct (double) cell
    fields: valid_cell and cell_size See respective internal classes for
    the content and computation of each field.
    
    Note that the filter needs to be run again if cells are refined after
    its execution.
    
    @sa
    HyperTreeGridCellSizeStrategy HyperTreeGridValidCellStrategy
    HyperTreeGridGenerateFieldStrategy HyperTreeGrid
    HyperTreeGridAlgorithm
    
    @par Thanks: This class was originally written by Jacques-Bernard
    Lekien, 2023 This work was supported by Commissariat a l'Energie
    Atomique CEA, DAM, DIF, F-91297 Arpajon, France.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHyperTreeGridGenerateFields, obj, update, **traits)
    
    compute_cell_center_array = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _compute_cell_center_array_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeCellCenterArray,
                        self.compute_cell_center_array_)

    compute_cell_size_array = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _compute_cell_size_array_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeCellSizeArray,
                        self.compute_cell_size_array_)

    compute_total_visible_volume_array = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _compute_total_visible_volume_array_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeTotalVisibleVolumeArray,
                        self.compute_total_visible_volume_array_)

    compute_valid_cell_array = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _compute_valid_cell_array_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeValidCellArray,
                        self.compute_valid_cell_array_)

    cell_center_array_name = traits.String('CellCenter', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _cell_center_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCellCenterArrayName,
                        self.cell_center_array_name)

    cell_size_array_name = traits.String('CellSize', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _cell_size_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCellSizeArrayName,
                        self.cell_size_array_name)

    total_visible_volume_array_name = traits.String('TotalVisibleVolume', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _total_visible_volume_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTotalVisibleVolumeArrayName,
                        self.total_visible_volume_array_name)

    valid_cell_array_name = traits.String('ValidCell', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _valid_cell_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetValidCellArrayName,
                        self.valid_cell_array_name)

    _updateable_traits_ = \
    (('compute_cell_center_array', 'GetComputeCellCenterArray'),
    ('compute_cell_size_array', 'GetComputeCellSizeArray'),
    ('compute_total_visible_volume_array',
    'GetComputeTotalVisibleVolumeArray'), ('compute_valid_cell_array',
    'GetComputeValidCellArray'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('cell_center_array_name', 'GetCellCenterArrayName'),
    ('cell_size_array_name', 'GetCellSizeArrayName'),
    ('total_visible_volume_array_name', 'GetTotalVisibleVolumeArrayName'),
    ('valid_cell_array_name', 'GetValidCellArrayName'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'compute_cell_center_array',
    'compute_cell_size_array', 'compute_total_visible_volume_array',
    'compute_valid_cell_array', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'cell_center_array_name',
    'cell_size_array_name', 'object_name', 'progress_text',
    'total_visible_volume_array_name', 'valid_cell_array_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HyperTreeGridGenerateFields, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HyperTreeGridGenerateFields properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['compute_cell_center_array', 'compute_cell_size_array',
            'compute_total_visible_volume_array', 'compute_valid_cell_array'], [],
            ['abort_output', 'cell_center_array_name', 'cell_size_array_name',
            'object_name', 'total_visible_volume_array_name',
            'valid_cell_array_name']),
            title='Edit HyperTreeGridGenerateFields properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HyperTreeGridGenerateFields properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

