# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class SerDesMock(Object):
    r"""
    SerDesMock - A mock interface for testing the ser_des infrastructure
    
    Superclass: Object
    
    Provides all properties supported by ser_des and member functions that
    can be invoked by the `Invoker`.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkSerDesMock, obj, update, **traits)
    
    def return_bounding_box(self):
        """
        return_bounding_box(self) -> BoundingBox
        C++: BoundingBox return_bounding_box()"""
        ret = wrap_vtk(self._vtk_obj.ReturnBoundingBox())
        return ret
        

    def return_c_style_enum(self):
        """
        return_c_style_enum(self) -> CStyleEnum
        C++: CStyleEnum return_c_style_enum()"""
        ret = self._vtk_obj.ReturnCStyleEnum()
        return ret
        

    def return_char_pointer(self):
        """
        return_char_pointer(self) -> str
        C++: const char *return_char_pointer()"""
        ret = self._vtk_obj.ReturnCharPointer()
        return ret
        

    def return_color3d(self):
        """
        return_color3d(self) -> Color3d
        C++: Color3d return_color3d()"""
        ret = wrap_vtk(self._vtk_obj.ReturnColor3d())
        return ret
        

    def return_color3f(self):
        """
        return_color3f(self) -> Color3f
        C++: Color3f return_color3f()"""
        ret = wrap_vtk(self._vtk_obj.ReturnColor3f())
        return ret
        

    def return_color3ub(self):
        """
        return_color3ub(self) -> Color3ub
        C++: Color3ub return_color3ub()"""
        ret = wrap_vtk(self._vtk_obj.ReturnColor3ub())
        return ret
        

    def return_color4d(self):
        """
        return_color4d(self) -> Color4d
        C++: Color4d return_color4d()"""
        ret = wrap_vtk(self._vtk_obj.ReturnColor4d())
        return ret
        

    def return_color4f(self):
        """
        return_color4f(self) -> Color4f
        C++: Color4f return_color4f()"""
        ret = wrap_vtk(self._vtk_obj.ReturnColor4f())
        return ret
        

    def return_color4ub(self):
        """
        return_color4ub(self) -> Color4ub
        C++: Color4ub return_color4ub()"""
        ret = wrap_vtk(self._vtk_obj.ReturnColor4ub())
        return ret
        

    def return_member_scoped_enum(self):
        """
        return_member_scoped_enum(self) -> MemberScopedEnum
        C++: MemberScopedEnum return_member_scoped_enum()"""
        ret = self._vtk_obj.ReturnMemberScopedEnum()
        return ret
        

    def return_numeric_array(self):
        """
        return_numeric_array(self) -> (float, float, float, float)
        C++: float *return_numeric_array()"""
        ret = self._vtk_obj.ReturnNumericArray()
        return ret
        

    def return_numeric_scalar(self):
        """
        return_numeric_scalar(self) -> float
        C++: double return_numeric_scalar()"""
        ret = self._vtk_obj.ReturnNumericScalar()
        return ret
        

    def return_rectd(self):
        """
        return_rectd(self) -> Rectd
        C++: Rectd return_rectd()"""
        ret = wrap_vtk(self._vtk_obj.ReturnRectd())
        return ret
        

    def return_rectf(self):
        """
        return_rectf(self) -> Rectf
        C++: Rectf return_rectf()"""
        ret = wrap_vtk(self._vtk_obj.ReturnRectf())
        return ret
        

    def return_recti(self):
        """
        return_recti(self) -> Recti
        C++: Recti return_recti()"""
        ret = wrap_vtk(self._vtk_obj.ReturnRecti())
        return ret
        

    def return_std_string(self):
        """
        return_std_string(self) -> str
        C++: std::string return_std_string()"""
        ret = self._vtk_obj.ReturnStdString()
        return ret
        

    def return_std_vector_of_int(self):
        """
        return_std_vector_of_int(self) -> (int, ...)
        C++: std::vector<int> return_std_vector_of_int()"""
        ret = self._vtk_obj.ReturnStdVectorOfInt()
        return ret
        

    def return_std_vector_of_real(self):
        """
        return_std_vector_of_real(self) -> (float, ...)
        C++: std::vector<float> return_std_vector_of_real()"""
        ret = self._vtk_obj.ReturnStdVectorOfReal()
        return ret
        

    def return_std_vector_of_std_string(self):
        """
        return_std_vector_of_std_string(self) -> (str, ...)
        C++: std::vector<std::string> return_std_vector_of_std_string()"""
        ret = self._vtk_obj.ReturnStdVectorOfStdString()
        return ret
        

    def return_tuple_int3(self):
        """
        return_tuple_int3(self) -> Tuple_IiLi3EE
        C++: Tuple<int, 3> return_tuple_int3()"""
        ret = wrap_vtk(self._vtk_obj.ReturnTupleInt3())
        return ret
        

    def return_vtk_object_raw_pointer(self):
        """
        return_vtk_object_raw_pointer(self) -> SerDesMockObject
        C++: SerDesMockObject *return_vtk_object_raw_pointer()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVTKObjectRawPointer())
        return ret
        

    def return_vtk_smart_pointer(self):
        """
        return_vtk_smart_pointer(self) -> SerDesMockObject
        C++: SmartPointer<vtkSerDesMockObject> return_vtk_smart_pointer()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVTKSmartPointer())
        return ret
        

    def return_vector2d(self):
        """
        return_vector2d(self) -> Vector2d
        C++: Vector2d return_vector2d()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector2d())
        return ret
        

    def return_vector2f(self):
        """
        return_vector2f(self) -> Vector2f
        C++: Vector2f return_vector2f()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector2f())
        return ret
        

    def return_vector2i(self):
        """
        return_vector2i(self) -> Vector2i
        C++: Vector2i return_vector2i()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector2i())
        return ret
        

    def return_vector3d(self):
        """
        return_vector3d(self) -> Vector3d
        C++: Vector3d return_vector3d()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector3d())
        return ret
        

    def return_vector3f(self):
        """
        return_vector3f(self) -> Vector3f
        C++: Vector3f return_vector3f()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector3f())
        return ret
        

    def return_vector3i(self):
        """
        return_vector3i(self) -> Vector3i
        C++: Vector3i return_vector3i()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector3i())
        return ret
        

    def return_vector4d(self):
        """
        return_vector4d(self) -> Vector4d
        C++: Vector4d return_vector4d()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector4d())
        return ret
        

    def return_vector4i(self):
        """
        return_vector4i(self) -> Vector4i
        C++: Vector4i return_vector4i()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVector4i())
        return ret
        

    def return_vector_int3(self):
        """
        return_vector_int3(self) -> Vector_IiLi3EE
        C++: Vector<int, 3> return_vector_int3()"""
        ret = wrap_vtk(self._vtk_obj.ReturnVectorInt3())
        return ret
        

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(SerDesMock, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit SerDesMock properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit SerDesMock properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit SerDesMock properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

