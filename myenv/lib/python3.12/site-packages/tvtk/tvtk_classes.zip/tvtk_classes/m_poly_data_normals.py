# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.poly_data_normals import PolyDataNormals


class mPolyDataNormals(PolyDataNormals):
    r"""
    vtkmPolyDataNormals - compute normals for polygonal mesh
    
    Superclass: PolyDataNormals
    
    vtkmPolyDataNormals is a filter that computes point and/or cell
    normals for a polygonal mesh. The user specifies if they would like
    the point and/or cell normals to be computed by setting the
    compute_cell_normals and compute_point_normals flags.
    
    The computed normals (a FloatArray) are set to be the active
    normals (using set_normals()) of the point_data and/or the cell_data
    (respectively) of the output poly_data. The name of these arrays is
    "Normals".
    
    The algorithm works by determining normals for each polygon and then
    averaging them at shared points.
    
    @warning
    Normals are computed only for polygons and triangles. Normals are not
    computed for lines, vertices, or triangle strips.
    
    @sa
    For high-performance rendering, you could use
    vtkmTriangleMeshPointNormals if you know that you have a triangle
    mesh which does not require splitting nor consistency check on the
    cell orientations.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkmPolyDataNormals, obj, update, **traits)
    
    force_vt_km = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _force_vt_km_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetForceVTKm,
                        self.force_vt_km_)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('force_vt_km', 'GetForceVTKm'), ('auto_orient_normals',
    'GetAutoOrientNormals'), ('compute_cell_normals',
    'GetComputeCellNormals'), ('compute_point_normals',
    'GetComputePointNormals'), ('consistency', 'GetConsistency'),
    ('flip_normals', 'GetFlipNormals'), ('non_manifold_traversal',
    'GetNonManifoldTraversal'), ('splitting', 'GetSplitting'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('feature_angle', 'GetFeatureAngle'), ('output_points_precision',
    'GetOutputPointsPrecision'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'auto_orient_normals', 'compute_cell_normals',
    'compute_point_normals', 'consistency', 'debug', 'flip_normals',
    'force_vt_km', 'global_warning_display', 'non_manifold_traversal',
    'release_data_flag', 'splitting', 'abort_output', 'feature_angle',
    'object_name', 'output_points_precision', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(mPolyDataNormals, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit mPolyDataNormals properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['auto_orient_normals', 'compute_cell_normals',
            'compute_point_normals', 'consistency', 'flip_normals', 'force_vt_km',
            'non_manifold_traversal', 'splitting'], [], ['abort_output',
            'feature_angle', 'object_name', 'output_points_precision']),
            title='Edit mPolyDataNormals properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit mPolyDataNormals properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

