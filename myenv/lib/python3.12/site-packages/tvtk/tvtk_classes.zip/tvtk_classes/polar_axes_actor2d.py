# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.actor2d import Actor2D


class PolarAxesActor2D(Actor2D):
    r"""
    PolarAxesActor2D - Display polar axes in Viewport 2D space.
    
    Superclass: Actor2D
    
    The polar axes actor is drawn on overlay. It displays polar
    coordinates. It is made of concentric axes linked with arcs.
    
    @warning
    Please be aware that the axes coordinate values are subject to
    perspective effects. With perspective projection, the computed
    distances may look wrong. These effects are not present when parallel
    projection is enabled. (@sa Camera::ParallelProjectionOn())
    
    It is the polar counter part of LegendScaleActor.
    @sa RadialGridActor2D
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPolarAxesActor2D, obj, update, **traits)
    
    axes_length = traits.Float(100.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the length of each axis in viewport coordinates. Default
        is 100.
        """
    )

    def _axes_length_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAxesLength,
                        self.axes_length)

    def _get_axes_text_property(self):
        return wrap_vtk(self._vtk_obj.GetAxesTextProperty())
    def _set_axes_text_property(self, arg):
        old_val = self._get_axes_text_property()
        self._wrap_call(self._vtk_obj.SetAxesTextProperty,
                        deref_vtk(arg))
        self.trait_property_changed('axes_text_property', old_val, arg)
    axes_text_property = traits.Property(_get_axes_text_property, _set_axes_text_property, desc=\
        r"""
        
        """
    )

    end_angle = traits.Float(90.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set the angle for the last radial axis. Default is 90.
        """
    )

    def _end_angle_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetEndAngle,
                        self.end_angle)

    number_of_axes = traits.Int(6, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the number of Axes to use. Default is 6.
        """
    )

    def _number_of_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfAxes,
                        self.number_of_axes)

    number_of_axes_ticks = traits.Int(6, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the number of ticks for each axis. Default is 6.
        """
    )

    def _number_of_axes_ticks_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfAxesTicks,
                        self.number_of_axes_ticks)

    def get_origin(self, *args):
        """
        get_origin(self, origin:[float, float]) -> None
        C++: void get_origin(double origin[2])"""
        ret = self._wrap_call(self._vtk_obj.GetOrigin, *args)
        return ret

    def set_origin(self, *args):
        """
        set_origin(self, x:float, y:float) -> None
        C++: void set_origin(double x, double y)
        set_origin(self, origin:[float, float]) -> None
        C++: void set_origin(double origin[2])
        Set the origin of the radial measurement, in normalized viewport
        coordinates. Default is [0.5, 0.5].
        """
        ret = self._wrap_call(self._vtk_obj.SetOrigin, *args)
        return ret

    start_angle = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set the angle for the main radial axis. Default is 0.
        """
    )

    def _start_angle_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetStartAngle,
                        self.start_angle)

    _updateable_traits_ = \
    (('dragable', 'GetDragable'), ('pickable', 'GetPickable'),
    ('use_bounds', 'GetUseBounds'), ('visibility', 'GetVisibility'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('axes_length', 'GetAxesLength'),
    ('end_angle', 'GetEndAngle'), ('number_of_axes', 'GetNumberOfAxes'),
    ('number_of_axes_ticks', 'GetNumberOfAxesTicks'), ('start_angle',
    'GetStartAngle'), ('height', 'GetHeight'), ('layer_number',
    'GetLayerNumber'), ('position', 'GetPosition'), ('position2',
    'GetPosition2'), ('width', 'GetWidth'), ('estimated_render_time',
    'GetEstimatedRenderTime'), ('render_time_multiplier',
    'GetRenderTimeMultiplier'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'dragable', 'global_warning_display', 'pickable',
    'use_bounds', 'visibility', 'axes_length', 'end_angle',
    'estimated_render_time', 'height', 'layer_number', 'number_of_axes',
    'number_of_axes_ticks', 'object_name', 'position', 'position2',
    'render_time_multiplier', 'start_angle', 'width'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PolarAxesActor2D, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PolarAxesActor2D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['use_bounds', 'visibility'], [], ['axes_length', 'end_angle',
            'estimated_render_time', 'height', 'layer_number', 'number_of_axes',
            'number_of_axes_ticks', 'object_name', 'position', 'position2',
            'render_time_multiplier', 'start_angle', 'width']),
            title='Edit PolarAxesActor2D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PolarAxesActor2D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

