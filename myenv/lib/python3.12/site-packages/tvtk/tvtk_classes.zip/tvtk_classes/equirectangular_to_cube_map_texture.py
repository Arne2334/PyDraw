# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.open_gl_texture import OpenGLTexture


class EquirectangularToCubeMapTexture(OpenGLTexture):
    r"""
    EquirectangularToCubeMapTexture - compute a cubemap texture based
    on a standard equirectangular projection
    
    Superclass: OpenGLTexture
    
    This special texture converts a 2D projected texture in
    equirectangular format to a 3D cubemap using the GPU. The generated
    texture can be used as input for a skybox or an environment map for
    PBR shading.
    
    @sa Skybox Renderer::SetEnvironmentCubeMap
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkEquirectangularToCubeMapTexture, obj, update, **traits)
    
    cube_map_size = traits.Int(512, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _cube_map_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCubeMapSize,
                        self.cube_map_size)

    def _get_input_texture(self):
        return wrap_vtk(self._vtk_obj.GetInputTexture())
    def _set_input_texture(self, arg):
        old_val = self._get_input_texture()
        self._wrap_call(self._vtk_obj.SetInputTexture,
                        deref_vtk(arg))
        self.trait_property_changed('input_texture', old_val, arg)
    input_texture = traits.Property(_get_input_texture, _set_input_texture, desc=\
        r"""
        
        """
    )

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input as a ImageData object.  This method is for
        backwards compatibility.
        """
    )

    _updateable_traits_ = \
    (('cube_map', 'GetCubeMap'), ('edge_clamp', 'GetEdgeClamp'),
    ('interpolate', 'GetInterpolate'), ('mipmap', 'GetMipmap'),
    ('premultiplied_alpha', 'GetPremultipliedAlpha'), ('repeat',
    'GetRepeat'), ('restrict_power_of2_image_smaller',
    'GetRestrictPowerOf2ImageSmaller'), ('use_srgb_color_space',
    'GetUseSRGBColorSpace'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('color_mode',
    'GetColorMode'), ('quality', 'GetQuality'), ('cube_map_size',
    'GetCubeMapSize'), ('is_depth_texture', 'GetIsDepthTexture'),
    ('texture_type', 'GetTextureType'), ('blending_mode',
    'GetBlendingMode'), ('border_color', 'GetBorderColor'),
    ('maximum_anisotropic_filtering', 'GetMaximumAnisotropicFiltering'),
    ('wrap', 'GetWrap'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'cube_map', 'debug', 'edge_clamp',
    'global_warning_display', 'interpolate', 'mipmap',
    'premultiplied_alpha', 'release_data_flag', 'repeat',
    'restrict_power_of2_image_smaller', 'use_srgb_color_space',
    'color_mode', 'quality', 'abort_output', 'blending_mode',
    'border_color', 'cube_map_size', 'is_depth_texture',
    'maximum_anisotropic_filtering', 'object_name', 'progress_text',
    'texture_type', 'wrap'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(EquirectangularToCubeMapTexture, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit EquirectangularToCubeMapTexture properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['cube_map', 'edge_clamp', 'interpolate', 'mipmap',
            'premultiplied_alpha', 'repeat', 'restrict_power_of2_image_smaller',
            'use_srgb_color_space'], ['color_mode', 'quality'], ['abort_output',
            'blending_mode', 'border_color', 'cube_map_size', 'is_depth_texture',
            'maximum_anisotropic_filtering', 'object_name', 'texture_type',
            'wrap']),
            title='Edit EquirectangularToCubeMapTexture properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit EquirectangularToCubeMapTexture properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

