# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class SynchronizableActors(Object):
    r"""
    SynchronizableActors - abstract base class for synchronizing a
    collection of actors
    
    Superclass: Object
    
    SynchronizableActors is an abstract base class for communicating
    details about a collection of actors among a set of Renderer
    instances doing cooperative rendering in a tile-display or CAVE
    environment.
    
    @sa
    SynchronizedRenderers SynchronizableOpenGLAvatars
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkSynchronizableActors, obj, update, **traits)
    
    def clean_up_renderer(self, *args):
        """
        clean_up_renderer(self, ren:Renderer) -> None
        C++: virtual void clean_up_renderer(Renderer *ren)
        Perform any necessary cleanup tasks with the Renderer.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.CleanUpRenderer, *my_args)
        return ret

    def initialize_renderer(self, *args):
        """
        initialize_renderer(self, ren:Renderer) -> None
        C++: virtual void initialize_renderer(Renderer *ren)
        Perform any necessary initialization tasks with the Renderer.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.InitializeRenderer, *my_args)
        return ret

    def restore_from_stream(self, *args):
        """
        restore_from_stream(self, stream:MultiProcessStream,
            ren:Renderer) -> None
        C++: virtual void restore_from_stream(MultiProcessStream &stream,
             Renderer *ren)
        Read actor information from the stream, update actors already
        added to the Renderer.  Possibly create actors and add them to
        the renderer, or remove actors that are no longer needed.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.RestoreFromStream, *my_args)
        return ret

    def save_to_stream(self, *args):
        """
        save_to_stream(self, stream:MultiProcessStream, ren:Renderer)
            -> None
        C++: virtual void save_to_stream(MultiProcessStream &stream,
            Renderer *ren)
        Identify target actors added to the Renderer, save them to the
        stream.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SaveToStream, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(SynchronizableActors, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit SynchronizableActors properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit SynchronizableActors properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit SynchronizableActors properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

