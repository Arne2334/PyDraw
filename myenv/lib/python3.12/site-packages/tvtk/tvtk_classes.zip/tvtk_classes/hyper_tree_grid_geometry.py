# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.hyper_tree_grid_algorithm import HyperTreeGridAlgorithm


class HyperTreeGridGeometry(HyperTreeGridAlgorithm):
    r"""
    HyperTreeGridGeometry - Generate HyperTreeGrid external surface
    
    Superclass: HyperTreeGridAlgorithm
    
    Generate the external surface (vtkpoly_data) of the input 1D/2D/3D
    HyperTreeGrid. Delegate the work internally to different
    implementation classes depending on the dimension of the input
    hyper_tree_grid.
    
    In the HTG case the surface generated is:
    - 1D from a 1D HTG (segments)
    - 2D from a 2D and 3D HTG (faces)
    
    This filters also take account of interfaces, that will generate
    "cuts" over the generated segments/surfaces.
    
    @sa
    HyperTreeGrid HyperTreeGridAlgorithm
    
    @par Thanks: This class was written by Philippe Pebay, Joachim
    Pouderoux, and Charles Law, Kitware 2013 This class was modified by
    Guenole Harel and Jacques-Bernard Lekien, 2014 This class was
    rewritten by Philippe Pebay, 2016 This class was modified by
    Jacques-Bernard Lekien and Guenole Harel, 2018 This class has been
    corrected and extended by Jacques-Bernard Lekien to fully support the
    subcell notion of onion skin interface (mixed cell), 2023 This work
    was supported by Commissariat a l'Energie Atomique CEA, DAM, DIF,
    F-91297 Arpajon, France.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHyperTreeGridGeometry, obj, update, **traits)
    
    fill_material = tvtk_base.true_bool_trait(desc=\
        r"""
        If false, only draw the interface (lines). Otherwise, draw the
        full cell with interface (poly).
        
        default is true
        """
    )

    def _fill_material_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFillMaterial,
                        self.fill_material_)

    pass_through_cell_ids = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get for the pass_through_cell_ids boolean.
        
        When set to true this boolean ensures an array named with
        whatever is in `original_cell_id_array_name` gets created in the
        output holding the original cell ids
        
        default is false
        """
    )

    def _pass_through_cell_ids_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPassThroughCellIds,
                        self.pass_through_cell_ids_)

    merging = traits.Bool(False, enter_set=True, auto_set=False, desc=\
        r"""
        Turn on/off merging of coincident points using a locator. Note
        that when merging is on, points with different point attributes
        (e.g., normals) are merged, which may cause rendering artifacts.
        """
    )

    def _merging_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMerging,
                        self.merging)

    original_cell_id_array_name = traits.String('vtkOriginalCellIds', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the original_cell_id_array_name string.
        
        When pass_through_cell_ids is set to true, the name of the generated
        array is whatever is set in this variable.
        
        default to OriginalCellIds
        """
    )

    def _original_cell_id_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOriginalCellIdArrayName,
                        self.original_cell_id_array_name)

    _updateable_traits_ = \
    (('fill_material', 'GetFillMaterial'), ('pass_through_cell_ids',
    'GetPassThroughCellIds'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('merging',
    'GetMerging'), ('original_cell_id_array_name',
    'GetOriginalCellIdArrayName'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'fill_material', 'global_warning_display',
    'pass_through_cell_ids', 'release_data_flag', 'abort_output',
    'merging', 'object_name', 'original_cell_id_array_name',
    'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HyperTreeGridGeometry, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HyperTreeGridGeometry properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['fill_material', 'pass_through_cell_ids'], [], ['abort_output',
            'merging', 'object_name', 'original_cell_id_array_name']),
            title='Edit HyperTreeGridGeometry properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HyperTreeGridGeometry properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

