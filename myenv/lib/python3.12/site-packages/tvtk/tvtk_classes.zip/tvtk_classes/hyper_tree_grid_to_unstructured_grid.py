# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.hyper_tree_grid_algorithm import HyperTreeGridAlgorithm


class HyperTreeGridToUnstructuredGrid(HyperTreeGridAlgorithm):
    r"""
    HyperTreeGridToUnstructuredGrid - Convert hyper tree grid to
    unstructured grid.
    
    Superclass: HyperTreeGridAlgorithm
    
    Make explicit all leaves of a hyper tree grid by converting them to
    cells of an unstructured grid. Produces segments in 1D, rectangles in
    2D, right hexahedra in 3D. NB: The output will contain superimposed
    inter-element boundaries and pending nodes as a result of
    T-junctions.
    
    @sa
    HyperTreeGrid HyperTreeGridAlgorithm
    
    @par Thanks: This class was written by Philippe Pebay, Joachim
    Pouderoux, and Charles Law, Kitware 2012 This class was modified by
    Guenole Harel and Jacques-Bernard Lekien, 2014 This class was
    rewritten by Philippe Pebay, 2016 This class was modified by
    Jacques-Bernard Lekien, 2018 This class was corriged (used
    orientation) by Jacques-Bernard Lekien, 2018 This work was supported
    by Commissariat a l'Energie Atomique CEA, DAM, DIF, F-91297 Arpajon,
    France.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHyperTreeGridToUnstructuredGrid, obj, update, **traits)
    
    add_original_ids = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _add_original_ids_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAddOriginalIds,
                        self.add_original_ids_)

    _updateable_traits_ = \
    (('add_original_ids', 'GetAddOriginalIds'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'add_original_ids', 'debug',
    'global_warning_display', 'release_data_flag', 'abort_output',
    'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HyperTreeGridToUnstructuredGrid, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HyperTreeGridToUnstructuredGrid properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['add_original_ids'], [], ['abort_output', 'object_name']),
            title='Edit HyperTreeGridToUnstructuredGrid properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HyperTreeGridToUnstructuredGrid properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

