# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.partitioned_data_set_collection_algorithm import PartitionedDataSetCollectionAlgorithm


class EnSightGoldCombinedReader(PartitionedDataSetCollectionAlgorithm):
    r"""
    EnSightGoldCombinedReader - class to read en_sight Gold files
    
    Superclass: PartitionedDataSetCollectionAlgorithm
    
    EnSightGoldCombinedReader is a class to read en_sight Gold files
    into vtk. This reader produces a PartitionedDataSetCollection.
    
    The reader allows for selecting which parts to load, with all parts
    being loaded by default. It also caches geometry when it is
    determined to be static instead of rereading the geometry file on
    every time step.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkEnSightGoldCombinedReader, obj, update, **traits)
    
    case_file_name = tvtk_base.vtk_file_name("", desc=\
        r"""
        Set/Get the case file name.
        """
    )

    def _case_file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCaseFileName,
                        self.case_file_name)

    def _get_controller(self):
        return wrap_vtk(self._vtk_obj.GetController())
    def _set_controller(self, arg):
        old_val = self._get_controller()
        self._wrap_call(self._vtk_obj.SetController,
                        deref_vtk(arg))
        self.trait_property_changed('controller', old_val, arg)
    controller = traits.Property(_get_controller, _set_controller, desc=\
        r"""
        Get/Set the controller
        """
    )

    file_path = traits.Trait(None, None, traits.String(enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the case file name.
        """
    )

    def _file_path_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFilePath,
                        self.file_path)

    part_of_sos_file = traits.Bool(False, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get part_of_sos_file. If true, this reader is being read as part
        of an SOS file and this reader will skip some communication (if
        running in parallel), to allow EnSightSOSGoldReader to handle
        that.
        """
    )

    def _part_of_sos_file_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPartOfSOSFile,
                        self.part_of_sos_file)

    time_value = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the time value.
        """
    )

    def _time_value_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTimeValue,
                        self.time_value)

    def _get_all_time_steps(self):
        return wrap_vtk(self._vtk_obj.GetAllTimeSteps())
    all_time_steps = traits.Property(_get_all_time_steps, desc=\
        r"""
        Get the time values per time set
        """
    )

    def _get_cell_array_selection(self):
        return wrap_vtk(self._vtk_obj.GetCellArraySelection())
    cell_array_selection = traits.Property(_get_cell_array_selection, desc=\
        r"""
        Cell array selection, to determine which cell arrays are loaded.
        """
    )

    def _get_field_array_selection(self):
        return wrap_vtk(self._vtk_obj.GetFieldArraySelection())
    field_array_selection = traits.Property(_get_field_array_selection, desc=\
        r"""
        Field data array selection, to determine which arrays are loaded.
        """
    )

    def _get_part_names(self):
        return wrap_vtk(self._vtk_obj.GetPartNames())
    part_names = traits.Property(_get_part_names, desc=\
        r"""
        Get the names of all parts that are found in this casefile during
        en_sight_data_set::get_part_info().
        """
    )

    def _get_part_selection(self):
        return wrap_vtk(self._vtk_obj.GetPartSelection())
    part_selection = traits.Property(_get_part_selection, desc=\
        r"""
        Part selection, to determine which blocks/parts are loaded.
        """
    )

    def _get_point_array_selection(self):
        return wrap_vtk(self._vtk_obj.GetPointArraySelection())
    point_array_selection = traits.Property(_get_point_array_selection, desc=\
        r"""
        Point array selection, to determine which point arrays are
        loaded.
        """
    )

    def can_read_file(self, *args):
        """
        can_read_file(self, casefilename:str) -> int
        C++: int can_read_file(const char *casefilename)
        Checks version information in the case file to determine if the
        file can be read by this reader.
        """
        ret = self._wrap_call(self._vtk_obj.CanReadFile, *args)
        return ret

    def set_pdc_info_for_loaded_parts(self, *args):
        """
        set_pdc_info_for_loaded_parts(self, indices:IdTypeArray,
            names:StringArray) -> None
        C++: void set_pdc_info_for_loaded_parts(
            SmartPointer<vtkIdTypeArray> indices,
            SmartPointer<vtkStringArray> names)
        Sets information about parts to be loaded.
        
        This must be called when loading data through a SOS file. It's
        possible that some casefiles may not include info on all parts
        (even as an empty part). The EnSightSOSGoldReader looks at
        which parts are to be loaded, assigns them ids in the output
        PartitionedDataSetCollection, and provides the part names,
        since they may not be available in the current casefile. This
        ensures that all ranks will have the same structure for the
        output PDC and matching name metadata.
        
        @param indices Provides the index into the output
            PartitionedDataSetCollection for all
        parts. It should be the same size as the total number of parts
        across all casefiles being loaded by an SOS file. If a part is
        not to be loaded, its value should be -1.
        @param names The names of only the parts to actually be loaded.
            This is indexed by its index in
        the output PDC.
        """
        my_args = deref_array(args, [('vtkIdTypeArray', 'vtkStringArray')])
        ret = self._wrap_call(self._vtk_obj.SetPDCInfoForLoadedParts, *my_args)
        return ret

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('case_file_name', 'GetCaseFileName'), ('file_path', 'GetFilePath'),
    ('part_of_sos_file', 'GetPartOfSOSFile'), ('time_value',
    'GetTimeValue'), ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'case_file_name', 'file_path',
    'object_name', 'part_of_sos_file', 'progress_text', 'time_value'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(EnSightGoldCombinedReader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit EnSightGoldCombinedReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'case_file_name', 'file_path',
            'object_name', 'part_of_sos_file', 'time_value']),
            title='Edit EnSightGoldCombinedReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit EnSightGoldCombinedReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

