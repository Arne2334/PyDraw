# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.partitioned_data_set_collection_algorithm import PartitionedDataSetCollectionAlgorithm


class Cesium3DTilesReader(PartitionedDataSetCollectionAlgorithm):
    r"""
    Cesium3DTilesReader - Reads a Cesium 3D Tiles tileset
    
    Superclass: PartitionedDataSetCollectionAlgorithm
    
    Reads a Cesium 3D Tiles dataset as a PartitionedDataSet. If the
    reader is used in a parallel environment it will try to balance the
    number of tiles read on each rank.  Currently, the reader only works
    with tiles saved using GLTF, GLB or b3dm formats.  Point coordinates
    in the produced VTK dataset are stored in Cartesian coordinates (cart
    proj string), as they are in the tileset. Textures can be applied
    using get_tile_reader to get access to the reader for each tile which
    provides access to the texture present in that tile. For a b3dm tile,
    we provide access to the GLTF reader for the GLTF binary embedded
    inside the tile. See the test for this reader for an example on how
    to do that.
    
    BREAKING_CHANGE: In VTK 9.3.0, a version of this reader (that did not
    support textures) produced a PartitionedDataSet output, where each
    tile was a partition in that dataset. Now, each tile is a
    PartitionedDataSet in a PartitionedDataSetCollection. Each tile
    can be split into different partitions each with its own texture.
    This should not affect usage if you simply use the reader in a
    pipeline but you'll need to change how you iterate over the output if
    you needed to do a more advanced processing.
    
    @see GeoTransform, Cesium3DTilesWriter, GLTFReader
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCesium3DTilesReader, obj, update, **traits)
    
    file_name = tvtk_base.vtk_file_name("", desc=\
        r"""
        Set/Get the name of the file from which to read points.
        """
    )

    def _file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFileName,
                        self.file_name)

    level = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the Level (level of detail) in the tree where you want to
        read tiles from. We start with root tile and then we refine each
        tile recursively until we reach Level. Possible values are from 0
        to number_of_levels - 1. Initialized to number_of_levels - 1 (reads
        the most detailed tiles available)
        """
    )

    def _level_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLevel,
                        self.level)

    def get_tile_reader(self, *args):
        """
        get_tile_reader(self, index:int) -> GLTFReader
        C++: SmartPointer<vtkGLTFReader> get_tile_reader(size_t index)
        Return the GLTFReader used to read the tile. Both GLTF and
        b3dm tiles have an underlying GLTF reader.
        """
        ret = self._wrap_call(self._vtk_obj.GetTileReader, *args)
        return wrap_vtk(ret)

    def can_read_file(self, *args):
        """
        can_read_file(self, name:str) -> int
        C++: virtual int can_read_file(const char *name)
        Returns true if it can read the json file (it is a 3D Tiles
        tileset), false otherwise
        """
        ret = self._wrap_call(self._vtk_obj.CanReadFile, *args)
        return ret

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('file_name',
    'GetFileName'), ('level', 'GetLevel'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'file_name', 'level',
    'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Cesium3DTilesReader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Cesium3DTilesReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'file_name', 'level', 'object_name']),
            title='Edit Cesium3DTilesReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Cesium3DTilesReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

